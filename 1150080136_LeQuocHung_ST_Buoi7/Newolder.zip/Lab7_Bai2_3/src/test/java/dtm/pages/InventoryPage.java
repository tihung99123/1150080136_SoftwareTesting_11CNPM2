package dtm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class InventoryPage {
    private WebDriver driver;

    @FindBy(css = "select.product_sort_container")
    private WebElement sortDropdown;

    @FindBy(css = "button.btn_inventory")
    private List<WebElement> addToCartButtons;

    @FindBy(css = "button.cart_button")
    private List<WebElement> removeButtons;

    @FindBy(css = "span.shopping_cart_badge")
    private WebElement cartBadge;

    @FindBy(css = "a.shopping_cart_link")
    private WebElement cartLink;

    public InventoryPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void themSanPhamTheoTen(String tenSanPham) {
        // TODO: click button corresponding to product name
    }

    public void themNSanPhamDauTien(int n) {
        for (int i = 0; i < n && i < addToCartButtons.size(); i++) {
            addToCartButtons.get(i).click();
        }
    }

    public int laySoLuongBadge() {
        try {
            return Integer.parseInt(cartBadge.getText());
        } catch (Exception e) {
            return 0;
        }
    }

    public void sortSanPham(String option) {
        // TODO: select option in dropdown
    }

    public List<String> layDanhSachTenSanPham() {
        // TODO: return list of product names in current order
        return null;
    }

    public List<Double> layDanhSachGiaSanPham() {
        // TODO: return list of product prices in current order
        return null;
    }
}
