package dtm.tests;

import dtm.base.BaseTest;
import dtm.pages.InventoryPage;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TC_GioHangTest extends BaseTest {
    InventoryPage inventoryPage;

    @BeforeMethod
    public void chuanBi() {
        inventoryPage = new InventoryPage(getDriver());
        // TODO: perform login using valid credentials
    }

    @Test(groups={"smoke"}, description="TC_CART_001: Thêm 1 sản phẩm - badge = 1")
    public void themMotSanPham() {
        inventoryPage.themNSanPhamDauTien(1);
        // TODO: assert badge equals 1
    }

    @Test(groups={"smoke"}, description="TC_CART_002: Thêm 3 sản phẩm - badge = 3")
    public void them3SanPham() {
        inventoryPage.themNSanPhamDauTien(3);
        // TODO: assert badge equals 3
    }

    @Test(groups={"regression"}, description="TC_CART_003: Xoá hết -> giỏ trống")
    public void xoaHetSanPham() {
        // TODO: implement remove logic
    }

    @Test(groups={"regression"}, description="TC_CART_004: Sort giá tăng dần - đúng thứ tự")
    public void sortGiaTangDan() {
        // TODO: implement sort verification
    }

    // TODO: Cài đặt thêm >= 10 test methods từ danh sách đã thiết kế
}
