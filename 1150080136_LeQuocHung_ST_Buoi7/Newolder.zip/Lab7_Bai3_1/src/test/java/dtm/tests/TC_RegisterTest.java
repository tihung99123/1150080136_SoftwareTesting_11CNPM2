package dtm.tests;

import dtm.pages.RegisterPage;
import org.testng.annotations.Test;

public class TC_RegisterTest {
    @Test
    public void dummy() {
        // TODO: implement registration scenarios using RegisterPage
    }
}