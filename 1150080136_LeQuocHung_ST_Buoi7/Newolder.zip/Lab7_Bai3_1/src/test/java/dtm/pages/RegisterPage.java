package dtm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPage {
    private WebDriver driver;

    @FindBy(id="email_create")
    private WebElement emailCreate;

    @FindBy(id="SubmitCreate")
    private WebElement createButton;

    // TODO: fields for step2

    public RegisterPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void enterEmail(String email) {
        emailCreate.clear();
        emailCreate.sendKeys(email);
    }

    public void clickCreate() {
        createButton.click();
    }

    // TODO: methods for fill step2 and submit
}