package com.shopvn;

public class App {
    public static void main(String[] args) {
        System.out.println("Lab7_Bai1_2 project started");
    }
}