package dtm.data;

import org.testng.annotations.DataProvider;

public class DangNhapData {
    @DataProvider(name="loginData")
    public Object[][] loginData() {
        return new Object[][] {
            {"user1","pass1"},
            {"user2","pass2"}
        };
    }
}