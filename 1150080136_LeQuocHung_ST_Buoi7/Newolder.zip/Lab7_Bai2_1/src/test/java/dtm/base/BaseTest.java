package dtm.base;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public abstract class BaseTest {
    // TODO: khai báo ThreadLocal<WebDriver> để hỗ trợ parallel execution

    @BeforeMethod
    public void setUp(Method method) {
        // TODO: Khởi tạo ChromeDriver qua WebDriverManager
        // TODO: maximize window, set implicit wait 10s
        // TODO: Ghi log tên test đang chạy
    }

    @AfterMethod
    public void tearDown(ITestResult result) {
        // TODO: Nếu result là FAILURE -> chụp screenshot lưu vào /screenshots/
        // TODO: Đóng driver, remove ThreadLocal
    }

    public WebDriver getDriver() {
        // TODO: Trả về driver của thread hiện tại
        return null;
    }
}
