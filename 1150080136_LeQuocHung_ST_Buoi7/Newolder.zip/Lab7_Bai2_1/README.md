# Bài 2.1 – Cấu hình dự án và TestNG DataProvider cơ bản

Yêu cầu tạo Maven project `Lab7_BlackBox_Testing` với cấu trúc thư mục giống như hướng dẫn ảnh.

## Cấu trúc mẫu (Markdown / Excel)

| Thư mục / gói          | Nội dung                                           |
|------------------------|----------------------------------------------------|
| pom.xml                | cấu hình Maven, thêm Selenium, WebDriverManager, TestNG |
| testng.xml             | thiết lập suite chạy smoke                         |
| src/main/java/dtm      | chứa class tiện ích hoặc trống                     |
| src/test/java/dtm/base | `BaseTest.java` với @BeforeMethod/@AfterMethod     |
| src/test/java/dtm/data | chứa các DataProvider: `DangNhapData`, `GioHangData` |
| src/test/java/dtm/pages| Page Object classes (LoginPage, InventoryPage, CartPage, CheckoutPage) |
| src/test/java/dtm/tests| Test cases (TC_DangNhapTest, TC_GioHangTest, TC_TimKiemTest, TC_CheckoutTest) |

*Markdown table trên có thể dán vào Excel để khởi tạo bảng tài liệu.*

## Dependencies cần thêm vào pom.xml

```xml
<dependencies>
    <dependency>
        <groupId>org.seleniumhq.selenium</groupId>
        <artifactId>selenium-java</artifactId>
        <version>4.15.0</version>
    </dependency>
    <dependency>
        <groupId>io.github.bonigarcia</groupId>
        <artifactId>webdrivermanager</artifactId>
        <version>5.6.3</version>
    </dependency>
    <dependency>
        <groupId>org.testng</groupId>
        <artifactId>testng</artifactId>
        <version>7.8.0</version>
        <scope>test</scope>
    </dependency>
</dependencies>
```

## BaseTest skeleton (markdown snippet)

```java
package dtm.base;

public abstract class BaseTest {
    // TODO: khai báo ThreadLocal<WebDriver> để hỗ trợ parallel execution

    @BeforeMethod
    public void setUp(Method method) {
        // TODO: Khởi tạo ChromeDriver qua WebDriverManager
        // TODO: maximize window, set implicit wait 10s
        // TODO: Ghi log tên test đang chạy
    }

    @AfterMethod
    public void tearDown(ITestResult result) {
        // TODO: Nếu result là FAILURE -> chụp screenshot lưu vào /screenshots/
        // TODO: Đóng driver, remove ThreadLocal
    }

    public WebDriver getDriver() {
        // TODO: Trả về driver của thread hiện tại
        return null;
    }
}
```

> Copy these markdown snippets into a spreadsheet or documentation as needed.