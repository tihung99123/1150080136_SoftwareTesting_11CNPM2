package com.shopvn.test;

import org.testng.annotations.DataProvider;

public class RegisterTestData {
    @DataProvider(name = "shopvnData")
    public Object[][] getTestData() {
        return new Object[][]{
                // TC ID | Họ tên | User | Email | SĐT | Pass | Confirm | Terms | Expected
                {"TC_REG_EP_001", "Nguyen Van A", "nguyena", "a@gm.com", "0987654321", "Admin@123", "Admin@123", true, "Đăng ký thành công!"},
                // Ho ten BVA
                {"TC_REG_BVA_001", "A", "nguyena", "a@gm.com", "0987654321", "Admin@123", "Admin@123", true, "Lỗi: Họ tên 2-50 ký tự"},
                {"TC_REG_BVA_002", "An", "nguyena", "a@gm.com", "0987654321", "Admin@123", "Admin@123", true, "Đăng ký thành công!"},
                {"TC_REG_EP_002", "Nguyen Van Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "nguyena", "a@gm.com", "0987654321", "Admin@123", "Admin@123", true, "Lỗi: Họ tên 2-50 ký tự"},
                // Username BVA
                {"TC_REG_BVA_003", "Nguyen A", "user", "a@gm.com", "0987654321", "Admin@123", "Admin@123", true, "Lỗi: Tên đăng nhập 5-20 ký tự"},
                {"TC_REG_BVA_004", "Nguyen A", "user1", "a@gm.com", "0987654321", "Admin@123", "Admin@123", true, "Đăng ký thành công!"},
                {"TC_REG_BVA_005", "Nguyen A", "thisusernameiswaytoolongforsystem", "a@gm.com", "0987654321", "Admin@123", "Admin@123", true, "Lỗi: Tên đăng nhập 5-20 ký tự"},
                {"TC_REG_SPEC_001", "Nguyen A", "1user", "a@gm.com", "0987654321", "Admin@123", "Admin@123", true, "Lỗi: Tên đăng nhập phải bắt đầu bằng chữ"},
                // Email cases
                {"TC_REG_SPEC_002", "Nguyen A", "nguyena", "invalidemail", "0987654321", "Admin@123", "Admin@123", true, "Lỗi: Email sai định dạng"},
                {"TC_REG_SPEC_003", "Nguyen A", "nguyena", "user@domain", "0987654321", "Admin@123", "Admin@123", true, "Đăng ký thành công!"},
                // Phone cases
                {"TC_REG_SPEC_004", "Nguyen A", "nguyena", "a@gm.com", "987654321", "Admin@123", "Admin@123", true, "Lỗi: SĐT VN phải bắt đầu bằng 0 và đủ 10 số"},
                {"TC_REG_SPEC_005", "Nguyen A", "nguyena", "a@gm.com", "1987654321", "Admin@123", "Admin@123", true, "Lỗi: SĐT VN phải bắt đầu bằng 0 và đủ 10 số"},
                {"TC_REG_SPEC_006", "Nguyen A", "nguyena", "a@gm.com", "0987654321", "admin123", "admin123", true, "Lỗi: Mật khẩu yếu"},
                {"TC_REG_SPEC_007", "Nguyen A", "nguyena", "a@gm.com", "0987654321", "ADMIN123", "ADMIN123", true, "Lỗi: Mật khẩu yếu"},
                {"TC_REG_SPEC_008", "Nguyen A", "nguyena", "a@gm.com", "0987654321", "Adminpass!", "Adminpass!", true, "Lỗi: Mật khẩu yếu"},
                {"TC_REG_SPEC_009", "Nguyen A", "nguyena", "a@gm.com", "0987654321", "Admin@abc", "Admin@abc", true, "Lỗi: Mật khẩu yếu"},
                {"TC_REG_SPEC_010", "Nguyen A", "nguyena", "a@gm.com", "0987654321", "Ad@1", "Ad@1", true, "Lỗi: Mật khẩu yếu"},
                {"TC_REG_SPEC_011", "Nguyen A", "nguyena", "a@gm.com", "0987654321", "VeryLongPasswordWithNumbersAndSymbols@1234567890", "VeryLongPasswordWithNumbersAndSymbols@1234567890", true, "Lỗi: Mật khẩu yếu"},
                {"TC_REG_SPEC_012", "Nguyen A", "nguyena", "a@gm.com", "0987654321", "Admin@123", "Wrong@123", true, "Lỗi: Xác nhận mật khẩu không khớp"},
                {"TC_REG_SPEC_013", "Nguyen A", "nguyena", "a@gm.com", "0987654321", "Admin@123", "Admin@123", false, "Lỗi: Chưa đồng ý điều khoản"},
                // extra EP cases
                {"TC_REG_EP_003", "Truong Dinh Z", "username20charss", "x@y.com", "0123456789", "Abc@1234", "Abc@1234", true, "Đăng ký thành công!"},
                {"TC_REG_EP_004", "Another Name", "usergood", "user+tag@example.com", "0987654321", "Passw0rd!", "Passw0rd!", true, "Đăng ký thành công!"}
        };
    }
}
