package com.shopvn.test;

import dtm.ShopVNRegistrationForm;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RegisterTest {
    ShopVNRegistrationForm form = new ShopVNRegistrationForm();

    @Test(dataProvider = "shopvnData", dataProviderClass = RegisterTestData.class)
    public void testRegistration(String tcId, String name, String user, String email, String phone, String pass, String confirm, boolean terms, String expected) {
        String actual = form.validateForm(name, user, email, phone, pass, confirm, terms);
        System.out.println("Running " + tcId + ": " + actual);
        Assert.assertEquals(actual, expected);
    }
}
