package dtm;

import java.util.regex.Pattern;

public class ShopVNRegistrationForm {
    // Hàm kiểm tra logic theo đặc tả Lab 7
    public String validateForm(String fullName, String username, String email, String phone, String pass, String confirm, boolean terms) {
        if (fullName.length() < 2 || fullName.length() > 50) return "Lỗi: Họ tên 2-50 ký tự";
        if (username.length() < 5 || username.length() > 20) return "Lỗi: Tên đăng nhập 5-20 ký tự";
        if (!Pattern.matches("^[a-zA-Z].*", username)) return "Lỗi: Tên đăng nhập phải bắt đầu bằng chữ";
        if (!Pattern.matches("^[A-Za-z0-9+_.-]+@(.+)$", email)) return "Lỗi: Email sai định dạng";
        if (!phone.startsWith("0") || phone.length() != 10) return "Lỗi: SĐT VN phải bắt đầu bằng 0 và đủ 10 số";
        
        // Kiểm tra độ phức tạp mật khẩu
        String passRegex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,32}$";
        if (!Pattern.matches(passRegex, pass)) return "Lỗi: Mật khẩu yếu";
        if (!pass.equals(confirm)) return "Lỗi: Xác nhận mật khẩu không khớp";
        if (!terms) return "Lỗi: Chưa đồng ý điều khoản";
        
        return "Đăng ký thành công!";
    }
}
