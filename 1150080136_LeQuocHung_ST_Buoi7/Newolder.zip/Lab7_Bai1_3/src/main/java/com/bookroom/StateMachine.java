package com.bookroom;

public class StateMachine {
    private String state = "S0";

    public String getState() {
        return state;
    }

    public void transition(String event) {
        // dummy implementation for testing purposes
        state = event; // placeholder, real logic can be added
    }
}
