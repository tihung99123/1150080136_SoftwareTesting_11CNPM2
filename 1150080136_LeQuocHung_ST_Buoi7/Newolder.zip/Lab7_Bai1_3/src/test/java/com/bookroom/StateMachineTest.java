package com.bookroom;

import org.junit.Test;
import static org.junit.Assert.*;

public class StateMachineTest {
    @Test
    public void dummyTest() {
        StateMachine sm = new StateMachine();
        assertEquals("S0", sm.getState());
    }
}