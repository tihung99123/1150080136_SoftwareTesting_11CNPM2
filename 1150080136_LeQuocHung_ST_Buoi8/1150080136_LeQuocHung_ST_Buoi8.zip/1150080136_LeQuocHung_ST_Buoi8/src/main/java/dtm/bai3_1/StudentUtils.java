package dtm.bai3_1;

public class StudentUtils {

    /**
     * Ham xep loai hoc sinh dung cho Bai 3.1
     * 
     * @param diemTB:   diem trung binh
     * @param coThiLai: bien co danh dau thi lai
     * @return ket qua xep loai
     */
    public static String xepLoai(double diemTB, boolean coThiLai) {
        if (diemTB < 0 || diemTB > 10) { // Node 1
            return "Diem khong hop le"; // Node 2
        }
        if (diemTB >= 8.5) { // Node 3
            return "Gioi"; // Node 4
        } else if (diemTB >= 7.0) { // Node 5
            return "Kha"; // Node 6
        } else if (diemTB >= 5.5) { // Node 7
            return "Trung Binh"; // Node 8
        } else {
            if (coThiLai) { // Node 9
                return "Thi lai"; // Node 10
            }
            return "Yeu - Hoc lai"; // Node 11
        }
    }
}
