package dtm.bai2_2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

/**
 * BAI 2.2 - LoginTest su dung DriverFactory (ThreadLocal)
 * Chay song song voi CartTest tren Thread rieng biet
 */
public class LoginTest {

    // KHONG dung bien static WebDriver - gay race condition
    // Lay driver tu DriverFactory.getDriver() thay the

    private static final By USERNAME_INPUT = By.id("user-name");
    private static final By PASSWORD_INPUT = By.id("password");
    private static final By LOGIN_BUTTON = By.id("login-button");
    private static final By ERROR_MESSAGE = By.cssSelector("[data-test='error']");
    private static final String BASE_URL = "https://www.saucedemo.com";

    @BeforeClass(alwaysRun = true)
    public void setUp() {
        // Moi class chay tren 1 thread rieng -> initDriver 1 lan cho ca class
        DriverFactory.initDriver("chrome");
        DriverFactory.getDriver().get(BASE_URL);
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        DriverFactory.quitDriver(); // dong va remove khoi ThreadLocal
    }

    // TC_BL1 - Dang nhap hop le
    @Test(description = "TC_BL1 - Dang nhap hop le → inventory.html")
    public void testLoginSuccess() {
        WebDriver driver = DriverFactory.getDriver();
        driver.get(BASE_URL); // Reset ve login page
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(USERNAME_INPUT))
                .sendKeys("standard_user");
        driver.findElement(PASSWORD_INPUT).sendKeys("secret_sauce");
        driver.findElement(LOGIN_BUTTON).click();
        wait.until(ExpectedConditions.urlContains("inventory.html"));
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory.html"),
                "TC_BL1 FAILED: Khong chuyen sang inventory.html. Thread: "
                        + Thread.currentThread().getName());
    }

    // TC_BL2 - Dang nhap sai mat khau
    @Test(description = "TC_BL2 - Dang nhap sai mat khau")
    public void testLoginFail() {
        WebDriver driver = DriverFactory.getDriver();
        driver.get(BASE_URL);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(USERNAME_INPUT))
                .sendKeys("standard_user");
        driver.findElement(PASSWORD_INPUT).sendKeys("wrong_pass");
        driver.findElement(LOGIN_BUTTON).click();
        String errText = wait.until(
                ExpectedConditions.visibilityOfElementLocated(ERROR_MESSAGE)).getText();
        Assert.assertTrue(errText.contains("Username and password do not match"),
                "TC_BL2 FAILED: Thong bao loi sai. Thread: "
                        + Thread.currentThread().getName());
    }

    // TC_BL3 - De trong username
    @Test(description = "TC_BL3 - De trong username → Username is required")
    public void testLoginEmptyUsername() {
        WebDriver driver = DriverFactory.getDriver();
        driver.get(BASE_URL);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.findElement(LOGIN_BUTTON).click();
        String errText = wait.until(
                ExpectedConditions.visibilityOfElementLocated(ERROR_MESSAGE)).getText();
        Assert.assertTrue(errText.contains("Username is required"),
                "TC_BL3 FAILED: Actual: [" + errText + "]. Thread: "
                        + Thread.currentThread().getName());
    }
}
