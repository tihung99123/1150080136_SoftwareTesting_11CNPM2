package dtm.bai3_2;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * BAI 3.2 - Thiet ke test suite dat 100% Branch Coverage
 * So luong test case toi thieu de bao phu toan bo 10 nhanh la: 6
 */
public class WaterBillTest {

    // (1) N1-True: soM3 = 0 <= 0 -> Tien = 0
    @Test(description = "TC1: so khoi nuoc = 0 (khong tieu thu)")
    public void testSoM3Khong() {
        Assert.assertEquals(WaterBillUtils.tinhTienNuoc(0, "dan_cu"), 0.0);
    }

    // (2) N1-False, N2-True: soM3 > 0, ho_ngheo -> don_gia 5000
    @Test(description = "TC2: Truong hop Ho ngheo (gia 5,000)")
    public void testHoNgheo() {
        Assert.assertEquals(WaterBillUtils.tinhTienNuoc(5, "ho_ngheo"), 25000.0);
    }

    // (3) N1-F, N2-F, N3-True, N4-True: dan_cu & soM3 = 5 <= 10 -> don_gia 7500
    @Test(description = "TC3: Dan cu, dung duoi 10 khoi (gia 7,500)")
    public void testDanCuDuoi10() {
        Assert.assertEquals(WaterBillUtils.tinhTienNuoc(5, "dan_cu"), 37500.0);
    }

    // (4) N1-F, N2-F, N3-T, N4-False, N5-True: dan_cu & 10 < soM3 <= 20 -> don_gia
    // 9900
    @Test(description = "TC4: Dan cu, dung tu 11-20 khoi (gia 9,900)")
    public void testDanCu_11_Den_20() {
        Assert.assertEquals(WaterBillUtils.tinhTienNuoc(15, "dan_cu"), 148500.0);
    }

    // (5) N1-F, N2-F, N3-T, N4-F, N5-False: dan_cu & soM3 > 20 -> don_gia 11400
    @Test(description = "TC5: Dan cu, dung tren 20 khoi (gia 11,400)")
    public void testDanCuTren20() {
        Assert.assertEquals(WaterBillUtils.tinhTienNuoc(25, "dan_cu"), 285000.0);
    }

    // (6) N1-F, N2-F, N3-False: kinh_doanh (khac dan_cu va ho_ngheo) -> don_gia
    // 22000
    @Test(description = "TC6: Kinh doanh hoac loai khac (gia 22,000)")
    public void testKinhDoanh() {
        Assert.assertEquals(WaterBillUtils.tinhTienNuoc(10, "kinh_doanh"), 220000.0);
    }
}
