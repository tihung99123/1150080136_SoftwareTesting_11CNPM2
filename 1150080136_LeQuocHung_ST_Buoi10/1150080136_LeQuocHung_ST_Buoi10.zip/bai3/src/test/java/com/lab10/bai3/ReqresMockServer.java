package com.lab10.bai3;

import com.sun.net.httpserver.HttpServer;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class ReqresMockServer {
    private static HttpServer server;

    public static void startServer() {
        try {
            if (server != null)
                return;
            server = HttpServer.create(new InetSocketAddress(8081), 0);

            // Mock GET /api/users?page=1 (Valid List Schema)
            server.createContext("/api/users", exchange -> {
                String method = exchange.getRequestMethod();
                if ("GET".equalsIgnoreCase(method)) {
                    String query = exchange.getRequestURI().getQuery();
                    if (query != null && query.contains("page=1")) {
                        String response = "{" +
                                "\"page\": 1," +
                                "\"total_pages\": 2," +
                                "\"data\": [" +
                                "{\"id\": 1, \"email\": \"t@reqres.in\", \"first_name\": \"A\", \"last_name\": \"B\", \"avatar\": \"url\"}"
                                +
                                "]" +
                                "}";
                        exchange.getResponseHeaders().add("Content-Type", "application/json");
                        exchange.sendResponseHeaders(200, response.getBytes().length);
                        OutputStream os = exchange.getResponseBody();
                        os.write(response.getBytes());
                        os.close();
                    }
                } else if ("POST".equalsIgnoreCase(method)) {
                    // Mock POST /api/users (Valid Create Schema)
                    String response = "{" +
                            "\"name\": \"Test\"," +
                            "\"job\": \"IT\"," +
                            "\"id\": \"999\"," +
                            "\"createdAt\": \"2026-03-24T13:00:00.000Z\"" +
                            "}";
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(201, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                }
            });

            // Mock GET /api/users/2 (Valid Single User Schema)
            server.createContext("/api/users/2", exchange -> {
                String method = exchange.getRequestMethod();
                if ("GET".equalsIgnoreCase(method)) {
                    String response = "{" +
                            "\"data\": {" +
                            "\"id\": 2, \"email\": \"t2@reqres.in\", \"first_name\": \"C\", \"last_name\": \"D\", \"avatar\": \"url2\""
                            +
                            "}," +
                            "\"support\": {" +
                            "\"url\": \"http\", \"text\": \"hi\"" +
                            "}" +
                            "}";
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                }
            });

            // Mock GET /api/users/demo-fail (Invalid Schema - Extra Field)
            // Thêm trường "extra_field" vào JSON object data
            server.createContext("/api/users/demo-fail", exchange -> {
                String method = exchange.getRequestMethod();
                if ("GET".equalsIgnoreCase(method)) {
                    String response = "{" +
                            "\"data\": {" +
                            "\"id\": 3, \"email\": \"f@reqres.in\", \"first_name\": \"F\", \"last_name\": \"F\", \"avatar\": \"url3\", \"extra_field\": \"Surprise!\""
                            +
                            "}," +
                            "\"support\": {" +
                            "\"url\": \"http\", \"text\": \"hi\"" +
                            "}" +
                            "}";
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                }
            });

            server.setExecutor(null);
            server.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
