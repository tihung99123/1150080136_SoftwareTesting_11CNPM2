package com.lab10.bai3;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

public class JsonSchemaTest extends ApiBaseTest {

    @Test(priority = 1)
    public void testUserListSchema() {
        given()
                .spec(requestSpec)
                .queryParam("page", 1)
                .when()
                .get("/api/users")
                .then()
                .spec(responseSpec)
                .statusCode(200)
                // Kiểm tra schema Danh sách user
                .body(matchesJsonSchemaInClasspath("schemas/user-list-schema.json"));
    }

    @Test(priority = 2)
    public void testUserSchema() {
        given()
                .spec(requestSpec)
                .when()
                .get("/api/users/2")
                .then()
                .spec(responseSpec)
                .statusCode(200)
                // Kiểm tra schema 1 user
                .body(matchesJsonSchemaInClasspath("schemas/user-schema.json"));
    }

    @Test(priority = 3)
    public void testCreateUserSchema() {
        // Truyền string JSON giả lập payload POST (Do bài này tập trung test RESPONSE
        // format)
        String requestBody = "{\"name\":\"Test\",\"job\":\"IT\"}";

        given()
                .spec(requestSpec)
                .body(requestBody)
                .when()
                .post("/api/users")
                .then()
                .spec(responseSpec)
                .statusCode(201)
                // Kiểm tra schema tạo user
                .body(matchesJsonSchemaInClasspath("schemas/create-user-schema.json"));
    }

    @Test(priority = 4)
    public void testDemoFailExtraFieldSchema() {
        // Gọi endpoint cố tình trả về field "extra_field" nhưng Schema user-schema ko
        // có
        // Cài đặt additionalProperties = false trong schema => Bắt buộc phải FAIL test
        // này
        given()
                .spec(requestSpec)
                .when()
                .get("/api/users/demo-fail")
                .then()
                .spec(responseSpec)
                .statusCode(200)
                // Kiểm tra schema 1 user => Sẽ tung ra lỗi rõ ràng ở Console Log (Unwanted
                // property...)
                .body(matchesJsonSchemaInClasspath("schemas/user-schema.json"));
    }
}
