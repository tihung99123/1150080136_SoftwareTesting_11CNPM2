package com.lab10.bai2;

import com.lab10.bai2.models.CreateUserRequest;
import com.lab10.bai2.models.UserResponse;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertNotEquals;

public class CrudTest extends ApiBaseTest {

    private String savedUserId;
    private String savedCreatedAt;

    @Test(priority = 1)
    public void testPostCreateUser() {
        // Cấu hình payload thông qua POJO theo chuẩn yêu cầu (MD file)
        CreateUserRequest payload = new CreateUserRequest("Tên", "Job");

        UserResponse response = given()
                .spec(requestSpec)
                .body(payload)
                .when()
                .post("/api/users")
                .then()
                .spec(responseSpec)
                .statusCode(201)
                // Ép Output JSON sang UserResponse POJO
                .extract().as(UserResponse.class);

        // Asserting validation trên object
        assertEquals(response.getName(), "Tên", "Tên input không khớp");
        assertNotNull(response.getId(), "Id bị null");
        assertNotNull(response.getCreatedAt(), "CreatedAt bị null");

        // Lưu trữ ID cho test GET tiếp theo
        this.savedUserId = response.getId();
        this.savedCreatedAt = response.getCreatedAt();
    }

    @Test(priority = 2, dependsOnMethods = "testPostCreateUser")
    public void testGetCreatedUser() {
        // POST -> GET xác nhận: Truyền savedUserId vào endpoint GET
        given()
                .spec(requestSpec)
                .when()
                .get("/api/users/" + savedUserId)
                .then()
                .spec(responseSpec)
                .statusCode(200)
                .body("data.name", equalTo("Tên"))
                .body("data.job", equalTo("Job"));
    }

    @Test(priority = 3)
    public void testPutUpdateUser() {
        CreateUserRequest payload = new CreateUserRequest("TênUpdate", "JobUpdate");

        UserResponse response = given()
                .spec(requestSpec)
                .body(payload)
                .when()
                .put("/api/users/2")
                .then()
                .spec(responseSpec)
                .statusCode(200)
                .extract().as(UserResponse.class);

        assertEquals(response.getJob(), "JobUpdate");
        assertNotNull(response.getUpdatedAt());
        assertNotEquals(response.getUpdatedAt(), savedCreatedAt); // updated khác create
    }

    @Test(priority = 4)
    public void testPatchUpdateUserPartial() {
        // Cập nhật 1 phần PATCH (cấu hình POJO bỏ đi biến Job nếu để null
        // JsonInclude.Include.NON_NULL)
        CreateUserRequest payload = new CreateUserRequest();
        payload.setName("Patched Name");

        UserResponse response = given()
                .spec(requestSpec)
                .body(payload)
                .when()
                .patch("/api/users/2")
                .then()
                .spec(responseSpec)
                .statusCode(200)
                .extract().as(UserResponse.class);

        assertEquals(response.getName(), "Patched Name");
        assertNotNull(response.getUpdatedAt());
    }

    @Test(priority = 5)
    public void testDeleteUser() {
        given()
                .spec(requestSpec)
                .when()
                .delete("/api/users/2")
                .then()
                .statusCode(204); // response HTTP 204 mặc định body rỗng hoàn toàn
    }
}
