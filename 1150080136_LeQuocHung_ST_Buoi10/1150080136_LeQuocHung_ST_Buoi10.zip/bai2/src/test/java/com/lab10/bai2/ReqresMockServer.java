package com.lab10.bai2;

import com.sun.net.httpserver.HttpServer;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.net.InetSocketAddress;

public class ReqresMockServer {
    private static HttpServer server;
    public static String createdId = "999";
    public static String createdName = "Ten";
    public static String createdJob = "Job";

    public static void startServer() {
        try {
            if (server != null)
                return;
            server = HttpServer.create(new InetSocketAddress(8080), 0);

            // POST /api/users
            server.createContext("/api/users", exchange -> {
                String method = exchange.getRequestMethod();
                if ("POST".equalsIgnoreCase(method)) {
                    byte[] requestBody = exchange.getRequestBody().readAllBytes();
                    String bodyString = new String(requestBody, StandardCharsets.UTF_8);

                    if (bodyString.contains("\"name\"")) {
                        createdName = bodyString.split("\"name\":\"")[1].split("\"")[0];
                    }
                    if (bodyString.contains("\"job\"")) {
                        createdJob = bodyString.split("\"job\":\"")[1].split("\"")[0];
                    }

                    String response = String.format(
                            "{\"name\":\"%s\",\"job\":\"%s\",\"id\":\"%s\",\"createdAt\":\"2026-03-24T13:00:00.000Z\"}",
                            createdName, createdJob, createdId);
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(201, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                }
            });

            // PUT, PATCH, DELETE cho id 2
            server.createContext("/api/users/2", exchange -> {
                String method = exchange.getRequestMethod();
                if ("PUT".equalsIgnoreCase(method)) {
                    byte[] requestBody = exchange.getRequestBody().readAllBytes();
                    String bodyString = new String(requestBody, StandardCharsets.UTF_8);
                    String job = "Job_Moi";
                    if (bodyString.contains("\"job\"")) {
                        job = bodyString.split("\"job\":\"")[1].split("\"")[0];
                    }
                    String response = String.format(
                            "{\"name\":\"Updated Name\",\"job\":\"%s\",\"updatedAt\":\"2026-03-24T14:00:00.000Z\"}",
                            job);
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                } else if ("PATCH".equalsIgnoreCase(method)) {
                    String response = "{\"name\":\"Patched Name\",\"updatedAt\":\"2026-03-24T15:00:00.000Z\"}";
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                } else if ("DELETE".equalsIgnoreCase(method)) {
                    exchange.sendResponseHeaders(204, -1);
                    exchange.getResponseBody().close();
                }
            });

            // GET xác nhận id động vửa tạo
            server.createContext("/api/users/999", exchange -> {
                if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                    String response = String.format("{\"data\":{\"id\":%s,\"name\":\"%s\",\"job\":\"%s\"}}", createdId,
                            createdName, createdJob);
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                }
            });

            server.setExecutor(null);
            server.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
