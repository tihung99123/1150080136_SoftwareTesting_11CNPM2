package com.lab10.bai6;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.BeforeClass;

public class ApiBaseTest {

    public RequestSpecification requestSpec;

    @BeforeClass
    public void setupBaseTest() {
        ReqresMockServer.startServer();

        requestSpec = new RequestSpecBuilder()
                .setBaseUri("http://localhost:8084")
                .setContentType(ContentType.JSON)
                .addFilter(new RequestLoggingFilter())
                .addFilter(new ResponseLoggingFilter())
                .build();
    }
}
