package com.lab10.bai6;

import io.restassured.response.Response;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

// Kế thừa Base Test theo đúng chuẩn các bài trước
public class IntegratedTest extends ApiBaseTest {

    // Đây là bước API check từ @BeforeMethod để in log
    @BeforeMethod
    public void getLoginTokenPrecondition() {
        Response res = given().spec(requestSpec)
                .body("{\"email\":\"eve.holt@reqres.in\",\"password\":\"cityslicka\"}")
                .post("/api/login");
        if (res.statusCode() == 200) {
            System.out.println(
                    "\n[PRECONDITION PREPARATION] Token retrieved: " + res.jsonPath().getString("token") + "\n");
        }
    }

    // Phần A: Khởi tạo 1 test độc lập nắm giữ login để phục vụ dependsOnMethods
    @Test(priority = 1)
    public void apiLoginPreconditionTest() {
        // Đây là bước API check: API Login
        given().spec(requestSpec)
                .body("{\"email\":\"eve.holt@reqres.in\",\"password\":\"cityslicka\"}")
                .post("/api/login")
                .then().statusCode(200);
    }

    // Phần A: UI Test bị ảnh hưởng trực tiếp bởi apiLoginPreconditionTest thông qua
    // dependsOnMethods
    @Test(priority = 2, dependsOnMethods = "apiLoginPreconditionTest")
    public void testUiPartA_SauceDemoLogin() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless=new"); // Tránh pop-up chiếm màn hình
        WebDriver driver = new ChromeDriver(options);

        try {
            // Đây là bước UI action: Đăng nhập form
            driver.get("https://www.saucedemo.com/");
            driver.findElement(By.id("user-name")).sendKeys("standard_user");
            driver.findElement(By.id("password")).sendKeys("secret_sauce");
            driver.findElement(By.id("login-button")).click();

            // Đây là assertion: Kiểm tra URL và Title
            Assert.assertTrue(driver.getCurrentUrl().contains("inventory"), "URL phải chứa 'inventory'");
            Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title phải là 'Swag Labs'");
        } finally {
            driver.quit();
        }
    }

    // Phần B: Luồng tích hợp đầy đủ (Throw SkipException)
    @Test(priority = 3)
    public void testUiPartB_FullIntegration() {
        // Đây là bước API check: Gọi GET /api/users để xác nhận status 200
        Response res = given().spec(requestSpec).get("/api/users");
        boolean isApiAlive = (res.statusCode() == 200);

        // Đây là thao tác đánh dấu SKIP nếu API sập
        if (!isApiAlive) {
            throw new SkipException("API reqres.in đang không phản hồi (FAIL). Đánh dấu SKIP test UI.");
        }

        // Khởi động WebDriver nếu chưa bị Skip
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless=new");
        WebDriver driver = new ChromeDriver(options);

        try {
            // Đây là bước UI action: Đăng nhập và thêm sản phẩm
            driver.get("https://www.saucedemo.com/");
            driver.findElement(By.id("user-name")).sendKeys("standard_user");
            driver.findElement(By.id("password")).sendKeys("secret_sauce");
            driver.findElement(By.id("login-button")).click();

            driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
            driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();

            // Đây là assertion: Kiểm chứng số lượng sản phẩm trong giỏ (badge)
            String badgeQuantity = driver.findElement(By.className("shopping_cart_badge")).getText();
            Assert.assertEquals(badgeQuantity, "2", "Lỗi: Badge số lượng giỏ hàng không đạt mức 2 sản phẩm");
        } finally {
            driver.quit();
        }
    }
}
