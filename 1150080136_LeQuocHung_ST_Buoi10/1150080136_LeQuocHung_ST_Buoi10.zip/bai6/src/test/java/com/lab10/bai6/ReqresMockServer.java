package com.lab10.bai6;

import com.sun.net.httpserver.HttpServer;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class ReqresMockServer {
    private static HttpServer server;

    public static void startServer() {
        try {
            if (server != null)
                return;
            server = HttpServer.create(new InetSocketAddress(8084), 0);

            server.createContext("/api/login", exchange -> {
                if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                    String response = "{\"token\": \"QpwL5tke4Pnpja7X4\"}";
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                }
            });

            server.createContext("/api/users", exchange -> {
                if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                    String response = "{\"data\": [{\"id\": 1}]}";
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                }
            });

            server.setExecutor(null);
            server.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
