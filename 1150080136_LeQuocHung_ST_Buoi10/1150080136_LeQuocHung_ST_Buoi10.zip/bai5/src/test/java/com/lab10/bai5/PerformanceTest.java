package com.lab10.bai5;

import io.qameta.allure.Step;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class PerformanceTest extends ApiBaseTest {

    @DataProvider(name = "slaData")
    public Object[][] slaData() {
        return new Object[][] {
                { "GET", "/api/users", 2000L },
                { "GET", "/api/users/2", 1500L },
                { "POST", "/api/users", 3000L },
                { "POST", "/api/login", 2000L },
                { "DELETE", "/api/users/2", 1000L }
        };
    }

    // Phần 1: Kiểm thử Data-Driven với Assertion tương ứng
    @Test(dataProvider = "slaData", priority = 1)
    @Step("Gọi {method} {endpoint} - SLA: {maxMs}ms")
    public void testApiSLA(String method, String endpoint, long maxMs) {

        // Khởi tạo request
        io.restassured.specification.RequestSpecification req = given().spec(requestSpec);

        // Nạp data tùy Endpoint
        if ("POST".equals(method)) {
            if ("/api/users".equals(endpoint)) {
                req.body("{\"name\":\"Tien\",\"job\":\"IT\"}");
            } else if ("/api/login".equals(endpoint)) {
                req.body("{\"email\":\"eve.holt@reqres.in\",\"password\":\"cityslicka\"}");
            }
        }

        Response response = null;
        if ("GET".equals(method))
            response = req.get(endpoint);
        else if ("POST".equals(method))
            response = req.post(endpoint);
        else if ("DELETE".equals(method))
            response = req.delete(endpoint);

        // Thống kê Log thực tế sau khi chạy ra console
        long actualTime = response.time();
        System.out.println("========== [XÁC MINH SLA] Phương thức " + method + " " + endpoint + " =========");
        System.out.println("-> Thời gian thực tế: " + actualTime + "ms");
        System.out.println("-> SLA Mục tiêu tối đa: " + maxMs + "ms");

        ValidatableResponse vRes = response.then();
        // Kiểm định Performance/SLA
        vRes.time(lessThanOrEqualTo(maxMs));

        // Kiểm định Assertion bổ sung theo đề bài
        if ("/api/users".equals(endpoint) && "GET".equals(method)) {
            vRes.body("data.size()", greaterThanOrEqualTo(1));
        } else if ("/api/users/2".equals(endpoint) && "GET".equals(method)) {
            vRes.body("data.id", equalTo(2));
        } else if ("/api/users".equals(endpoint) && "POST".equals(method)) {
            vRes.statusCode(201).body("id", notNullValue());
        } else if ("/api/login".equals(endpoint) && "POST".equals(method)) {
            vRes.statusCode(200).body("token", notNullValue());
        } else if ("/api/users/2".equals(endpoint) && "DELETE".equals(method)) {
            vRes.statusCode(204);
        }
    }

    // Phần 2: Chạy Loop 10 lần giám sát (Monitoring đơn giản)
    @Test(priority = 2)
    public void testMonitoringApi10Laps() {
        long min = Long.MAX_VALUE;
        long max = 0;
        long total = 0;

        System.out.println("\n========== BẮT ĐẦU MONITORING GIẢM SÁT 10 LẦN ==========");
        for (int i = 1; i <= 10; i++) {
            Response response = given().spec(requestSpec).get("/api/users");
            long t = response.time();
            System.out.println("Lần thứ " + i + ": Ghi nhận " + t + "ms");

            if (t < min)
                min = t;
            if (t > max)
                max = t;
            total += t;
        }
        long avg = total / 10;
        System.out.println("================= TỔNG KẾT MONITORING =================");
        System.out.println(
                "AVG (Trung bình): " + avg + "ms | MIN (Nhanh nhất): " + min + "ms | MAX (Chậm nhất): " + max + "ms");
        System.out.println("========================================================\n");
    }
}
