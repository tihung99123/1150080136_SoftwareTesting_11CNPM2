package com.lab10.bai5;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.BeforeClass;

public class ApiBaseTest {

    public RequestSpecification requestSpec;

    @BeforeClass
    public void setupBaseTest() {
        ReqresMockServer.startServer();

        // Bài 5 yêu cầu SLA linh hoạt tùy Endpoint nên ta KHÔNG GÁN
        // expectResponseTime() vào builder nữa.
        // Thay vào đó đánh giá Thời gian ngay tại trong Test Script để phù hợp.
        requestSpec = new RequestSpecBuilder()
                .setBaseUri("http://localhost:8083")
                .setContentType(ContentType.JSON)
                .addFilter(new RequestLoggingFilter())
                .addFilter(new ResponseLoggingFilter())
                .build();
    }
}
