package com.lab10.bai5;

import com.sun.net.httpserver.HttpServer;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class ReqresMockServer {
    private static HttpServer server;

    public static void startServer() {
        try {
            if (server != null)
                return;
            server = HttpServer.create(new InetSocketAddress(8083), 0);

            // Mock GET /api/users
            server.createContext("/api/users", exchange -> {
                String method = exchange.getRequestMethod();
                if ("GET".equalsIgnoreCase(method)) {
                    String query = exchange.getRequestURI().getQuery();
                    if (query == null || query.isEmpty()) {
                        String response = "{\"data\": [{\"id\": 1}]}";
                        exchange.getResponseHeaders().add("Content-Type", "application/json");
                        // Thêm Sleep cố tình làm delay giả lập độ trễ mạng để có min/max rõ ràng
                        try {
                            Thread.sleep(50);
                        } catch (Exception e) {
                        }
                        exchange.sendResponseHeaders(200, response.getBytes().length);
                        OutputStream os = exchange.getResponseBody();
                        os.write(response.getBytes());
                        os.close();
                    }
                } else if ("POST".equalsIgnoreCase(method)) {
                    String response = "{\"id\": \"100\"}";
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(201, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                }
            });

            // Mock GET /api/users/2
            server.createContext("/api/users/2", exchange -> {
                String method = exchange.getRequestMethod();
                if ("GET".equalsIgnoreCase(method)) {
                    String response = "{\"data\": {\"id\": 2}}";
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                } else if ("DELETE".equalsIgnoreCase(method)) {
                    exchange.sendResponseHeaders(204, -1);
                    exchange.getResponseBody().close();
                }
            });

            // Mock POST /api/login
            server.createContext("/api/login", exchange -> {
                if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                    String response = "{\"token\": \"QpwL5tke4Pnpja7X4\"}";
                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                }
            });

            server.setExecutor(null);
            server.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
