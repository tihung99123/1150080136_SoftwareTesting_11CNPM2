package com.lab10.bai1;

import com.sun.net.httpserver.HttpServer;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class ReqresMockServer {
    private static HttpServer server;

    public static void startServer() {
        try {
            if (server != null)
                return; // Tránh start lại nếu đã chạy
            server = HttpServer.create(new InetSocketAddress(8080), 0);

            // Mock endpoint danh sách User (page 1 & 2)
            server.createContext("/api/users", exchange -> {
                String query = exchange.getRequestURI().getQuery();
                String response = "{}";
                int statusCode = 200;

                if (query != null && query.contains("page=1")) {
                    response = "{\"page\":1,\"total_pages\":2,\"data\":[{\"id\":1,\"email\":\"george@reqres.in\",\"first_name\":\"George\",\"last_name\":\"Bluth\",\"avatar\":\"url\"}]}";
                } else if (query != null && query.contains("page=2")) {
                    response = "{\"page\":2,\"total_pages\":2,\"data\":[{\"id\":7,\"email\":\"michael@reqres.in\",\"first_name\":\"Michael\",\"last_name\":\"Lawson\",\"avatar\":\"url\"}]}";
                }

                exchange.getResponseHeaders().add("Content-Type", "application/json");
                exchange.sendResponseHeaders(statusCode, response.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            });

            // Mock endpoint User cụ thể (ID = 3)
            server.createContext("/api/users/3", exchange -> {
                String response = "{\"data\":{\"id\":3,\"email\":\"emma.wong@reqres.in\",\"first_name\":\"Emma\",\"last_name\":\"Wong\",\"avatar\":\"url\"}}";
                exchange.getResponseHeaders().add("Content-Type", "application/json");
                exchange.sendResponseHeaders(200, response.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            });

            // Mock endpoint User không tồn tại (ID = 9999)
            server.createContext("/api/users/9999", exchange -> {
                String response = "{}";
                exchange.getResponseHeaders().add("Content-Type", "application/json");
                exchange.sendResponseHeaders(404, response.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            });

            server.setExecutor(null);
            server.start();
            System.out.println("✅ Mock Server started on http://localhost:8080");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
