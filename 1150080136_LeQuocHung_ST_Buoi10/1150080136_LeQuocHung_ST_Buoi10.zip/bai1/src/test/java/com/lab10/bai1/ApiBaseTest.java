package com.lab10.bai1;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.annotations.BeforeClass;

import static org.hamcrest.Matchers.lessThan;

public class ApiBaseTest {

        protected RequestSpecification requestSpec;
        protected ResponseSpecification responseSpec;

        @BeforeClass
        public void setupBaseTest() {
                // Khởi động server ảo ReqresMockServer để bypass Cloudflare
                ReqresMockServer.startServer();

                // Khởi tạo RequestSpecification, trỏ về server ảo localhost
                requestSpec = new RequestSpecBuilder()
                                .setBaseUri("http://localhost:8080")
                                .setContentType(ContentType.JSON)
                                .addFilter(new RequestLoggingFilter())
                                .addFilter(new ResponseLoggingFilter())
                                .build();

                // Khởi tạo ResponseSpecification theo yêu cầu
                responseSpec = new ResponseSpecBuilder()
                                .expectContentType(ContentType.JSON)
                                .expectResponseTime(lessThan(3000L))
                                .build();
        }
}
