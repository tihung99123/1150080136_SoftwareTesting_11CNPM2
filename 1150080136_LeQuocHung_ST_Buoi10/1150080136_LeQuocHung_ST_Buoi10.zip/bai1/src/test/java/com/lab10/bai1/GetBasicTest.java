package com.lab10.bai1;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class GetBasicTest extends ApiBaseTest {

    @Test
    public void testGetUsersPage1() {
        // Test 1: GET /api/users?page=1 -> Kiểm tra status 200, page=1, total_pages >
        // 0, data.size() >= 1
        given()
                .spec(requestSpec)
                .queryParam("page", 1)
                .when()
                .get("/api/users")
                .then()
                .spec(responseSpec)
                .statusCode(200)
                .body("page", equalTo(1))
                .body("total_pages", greaterThan(0))
                .body("data.size()", greaterThanOrEqualTo(1));
    }

    @Test
    public void testGetUsersPage2() {
        // Test 2: GET /api/users?page=2 -> Kiểm tra page=2, mỗi user có id, email,
        // first_name, last_name, avatar
        given()
                .spec(requestSpec)
                .queryParam("page", 2)
                .when()
                .get("/api/users")
                .then()
                .spec(responseSpec)
                .statusCode(200)
                .body("page", equalTo(2))
                .body("data.id", everyItem(notNullValue()))
                .body("data.email", everyItem(notNullValue()))
                .body("data.first_name", everyItem(notNullValue()))
                .body("data.last_name", everyItem(notNullValue()))
                .body("data.avatar", everyItem(notNullValue()));
    }

    @Test
    public void testGetUser3() {
        // Test 3: GET /api/users/3 -> Kiểm tra id=3, email @reqres.in, first_name không
        // rỗng
        given()
                .spec(requestSpec)
                .when()
                .get("/api/users/3")
                .then()
                .spec(responseSpec)
                .statusCode(200)
                .body("data.id", equalTo(3))
                .body("data.email", endsWith("@reqres.in"))
                // emptyString() check in Matchers can be inverted with not()
                .body("data.first_name", allOf(notNullValue(), not(emptyString())));
    }

    @Test
    public void testGetUser9999() {
        // Test 4: GET /api/users/9999 -> Kiểm tra status 404, body là object rỗng {}
        given()
                .spec(requestSpec)
                .when()
                .get("/api/users/9999")
                .then()
                .spec(responseSpec)
                .statusCode(404)
                // Kiểm tra empty object
                .body("isEmpty()", is(true));
    }
}
