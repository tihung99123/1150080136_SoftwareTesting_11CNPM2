package com.lab10.bai4;

import com.sun.net.httpserver.HttpServer;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

public class ReqresMockServer {
    private static HttpServer server;

    public static void startServer() {
        try {
            if (server != null)
                return;
            server = HttpServer.create(new InetSocketAddress(8082), 0);

            // Mock /api/login endpoints
            server.createContext("/api/login", exchange -> {
                if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                    byte[] requestBody = exchange.getRequestBody().readAllBytes();
                    String bodyString = new String(requestBody, StandardCharsets.UTF_8).replaceAll("\\s+", "");

                    int status = 200;
                    String response = "";

                    // Kiểm tra email rỗng hoặc mất email
                    if (!bodyString.contains("\"email\"") || bodyString.contains("\"email\":\"\"")) {
                        status = 400;
                        response = "{\"error\":\"Missing email or username\"}";
                    }
                    // Kiểm tra password rỗng hoặc mất password
                    else if (!bodyString.contains("\"password\"") || bodyString.contains("\"password\":\"\"")) {
                        status = 400;
                        response = "{\"error\":\"Missing password\"}";
                    }
                    // Kiểm tra email không hợp lệ
                    else if (bodyString.contains("notexist") || bodyString.contains("invalid-email")) {
                        status = 400;
                        response = "{\"error\":\"user not found\"}";
                    }
                    // Đăng nhập thành công
                    else {
                        status = 200;
                        response = "{\"token\":\"QpwL5tke4Pnpja7X4\"}";
                    }

                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(status, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                }
            });

            // Mock /api/register endpoints
            server.createContext("/api/register", exchange -> {
                if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                    byte[] requestBody = exchange.getRequestBody().readAllBytes();
                    String bodyString = new String(requestBody, StandardCharsets.UTF_8).replaceAll("\\s+", "");

                    int status = 200;
                    String response = "";

                    if (!bodyString.contains("\"password\"")) {
                        status = 400;
                        response = "{\"error\":\"Missing password\"}";
                    } else {
                        status = 200;
                        response = "{\"id\":4,\"token\":\"QpwL5tke4Pnpja7X4\"}";
                    }

                    exchange.getResponseHeaders().add("Content-Type", "application/json");
                    exchange.sendResponseHeaders(status, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                }
            });

            server.setExecutor(null);
            server.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
