package com.lab10.bai4;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.response.ValidatableResponse;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class AuthTest extends ApiBaseTest {

    // Phần A: Test cố định (Đăng ký)
    @Test(priority = 1)
    public void testRegisterSuccess() {
        Map<String, String> body = new HashMap<>();
        body.put("email", "eve.holt@reqres.in");
        body.put("password", "pistol");

        given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post("/api/register")
                .then()
                .spec(responseSpec)
                .statusCode(200)
                .body("id", notNullValue())
                .body("token", notNullValue());
    }

    @Test(priority = 2)
    public void testRegisterMissingPassword() {
        Map<String, String> body = new HashMap<>();
        body.put("email", "sydney@fife");
        // Chủ ý không cấp password

        given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post("/api/register")
                .then()
                .spec(responseSpec)
                .statusCode(400)
                .body("error", equalTo("Missing password"));
    }

    // Phần B: Data-Driven cho Đăng Nhập
    @DataProvider(name = "loginScenarios")
    public Object[][] loginScenarios() {
        return new Object[][] {
                { "eve.holt@reqres.in", "cityslicka", 200, null },
                { "eve.holt@reqres.in", "", 400, "Missing password" },
                { "", "cityslicka", 400, "Missing email or username" },
                { "notexist@reqres.in", "wrongpass", 400, "user not found" },
                { "invalid-email", "pass123", 400, "user not found" }
        };
    }

    @Test(priority = 3, dataProvider = "loginScenarios")
    public void testLoginScenarios(String email, String password, int expectedStatus, String expectedError) {
        Map<String, String> body = new HashMap<>();

        // Theo hình chụp hướng dẫn, truyền email liên tục và kiểm tra rỗng password
        body.put("email", email);
        if (!password.isEmpty()) {
            body.put("password", password);
        }

        ValidatableResponse response = given()
                .spec(requestSpec)
                .body(body)
                .when()
                .post("/api/login")
                .then()
                .spec(responseSpec)
                .statusCode(expectedStatus);

        // Theo yêu cầu, parse JSON bắt báo lỗi chứa string
        if (expectedError != null) {
            response.body("error", containsString(expectedError));
        } else {
            response.body("token", notNullValue());
        }
    }
}
