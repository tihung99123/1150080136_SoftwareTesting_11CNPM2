package com.lab10.bai7;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class CommentApiTest extends ApiBaseTest {

    @Test
    public void testGetCommentsOfPost() {
        given().spec(requestSpec)
                .when().get("/posts/1/comments")
                .then().spec(responseSpec)
                .statusCode(200)
                // Lấy 5 comments
                .body("size()", equalTo(5))
                // Khẳng định mỗi comment đều có postId = 1 sử dụng lệnh lặp everyItem
                .body("postId", everyItem(equalTo(1)))
                .body("id", everyItem(notNullValue()))
                .body("name", everyItem(notNullValue()))
                .body("email", everyItem(notNullValue()))
                .body("body", everyItem(notNullValue()));
    }
}
