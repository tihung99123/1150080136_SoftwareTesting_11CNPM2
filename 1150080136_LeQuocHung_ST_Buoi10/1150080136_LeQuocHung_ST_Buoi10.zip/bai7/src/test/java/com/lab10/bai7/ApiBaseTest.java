package com.lab10.bai7;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.annotations.BeforeClass;

import static org.hamcrest.Matchers.lessThan;

public class ApiBaseTest {

    public RequestSpecification requestSpec;
    public ResponseSpecification responseSpec;

    @BeforeClass
    public void setupBaseTest() {
        // Hoàn toàn gọi API thật 100% ngoài internet (Không bị chặn như reqres.in) nên
        // không cần Mock Server.
        requestSpec = new RequestSpecBuilder()
                .setBaseUri("https://jsonplaceholder.typicode.com")
                .setContentType(ContentType.JSON)
                .addFilter(new RequestLoggingFilter())
                .addFilter(new ResponseLoggingFilter())
                .build();

        // 5. Yêu cầu bắt buộc SLA ASSERTION: response time < 3000ms cho TẤT CẢ các test
        responseSpec = new ResponseSpecBuilder()
                .expectResponseTime(lessThan(3000L))
                .build();
    }
}
