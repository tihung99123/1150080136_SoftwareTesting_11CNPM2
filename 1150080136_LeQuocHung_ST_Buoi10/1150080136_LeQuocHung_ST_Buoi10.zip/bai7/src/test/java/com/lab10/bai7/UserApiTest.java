package com.lab10.bai7;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

public class UserApiTest extends ApiBaseTest {

    @Test(priority = 1)
    public void testGetListUsers() {
        given().spec(requestSpec)
                .when().get("/users")
                .then().spec(responseSpec)
                .statusCode(200)
                // Trả về exacly 10 biến users
                .body("size()", equalTo(10));
    }

    @Test(priority = 2)
    public void testGetSingleUserWithSchema() {
        given().spec(requestSpec)
                .when().get("/users/1")
                .then().spec(responseSpec)
                .statusCode(200)
                // Cấu trúc Schema này yêu cầu phải có Nested Object "address" chứa zipcode và
                // city
                .body(matchesJsonSchemaInClasspath("schemas/UserSchema.json"));
    }
}
