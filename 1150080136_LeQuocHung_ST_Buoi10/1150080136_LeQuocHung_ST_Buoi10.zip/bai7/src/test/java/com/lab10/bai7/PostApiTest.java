package com.lab10.bai7;

import org.testng.annotations.Test;
import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

public class PostApiTest extends ApiBaseTest {

    @Test(priority = 1)
    public void testGetPostsList() {
        given().spec(requestSpec)
                .when().get("/posts")
                .then().spec(responseSpec)
                .statusCode(200)
                .body("size()", equalTo(100)); // Lấy chính xác 100 bài đăng
    }

    @Test(priority = 2)
    public void testGetSinglePost() {
        given().spec(requestSpec)
                .when().get("/posts/1")
                .then().spec(responseSpec)
                .statusCode(200)
                .body("id", equalTo(1))
                // Kiểm định Schema của Post
                .body(matchesJsonSchemaInClasspath("schemas/PostSchema.json"));
    }

    @Test(priority = 3)
    public void testCreatePost() {
        Map<String, Object> body = new HashMap<>();
        body.put("title", "Demo Title");
        body.put("body", "Test Automation Automation");
        body.put("userId", 1);

        given().spec(requestSpec)
                .body(body)
                .when().post("/posts")
                .then().spec(responseSpec)
                .statusCode(201) // Mã 201 khi khởi tạo
                .body("id", notNullValue())
                .body("title", equalTo("Demo Title"));
    }

    @Test(priority = 4)
    public void testUpdatePost() {
        Map<String, Object> body = new HashMap<>();
        body.put("id", 1);
        body.put("title", "Updated Title");
        body.put("body", "Updated body text");
        body.put("userId", 1);

        given().spec(requestSpec)
                .body(body)
                .when().put("/posts/1")
                .then().spec(responseSpec)
                .statusCode(200)
                .body("title", equalTo("Updated Title"));
    }

    @Test(priority = 5)
    public void testDeletePost() {
        given().spec(requestSpec)
                .when().delete("/posts/1")
                .then().spec(responseSpec)
                .statusCode(200); // JsonPlaceholder trả mã 200 cho lệnh xóa ảo
    }
}
